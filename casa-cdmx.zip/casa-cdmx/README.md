# 🏡 Casa CDMX — Agente de búsqueda

Agente automatizado para búsqueda de casa en renta, sur-poniente de Ciudad de México.

## Qué hace

- Corre cada mañana de lunes a sábado a las **7:00am hora CDMX** vía GitHub Actions
- Genera un reporte diario con enlaces pre-filtrados a 5 portales inmobiliarios
- Publica el reporte en GitHub Pages automáticamente
- Incluye evaluador interactivo para calificar propiedades con el sistema de pesos acordado

## Filtros aplicados

| Parámetro | Valor |
|---|---|
| Operación | Renta |
| Presupuesto máximo | $60,000 MXN/mes (mantenimiento incluido) |
| Tipo | Casa independiente o en condominio |
| Zona | Sur-poniente CDMX (Coyoacán, Del Valle, Pedregal, San Jerónimo...) |

## Sistema de evaluación (5 criterios)

| Criterio | Peso |
|---|---|
| 🌿 Jardín | 30% |
| 📍 Ubicación y colonia | 25% |
| 📐 Tamaño y distribución | 20% |
| 🔧 Estado del inmueble | 20% |
| 🚗 Estacionamiento | 5% |

> El precio es **filtro duro**, no criterio de rating.

## Setup (5 pasos)

### 1. Crear repositorio en GitHub
Crea un repositorio nuevo (puede ser privado) y sube estos archivos manteniendo la estructura de carpetas.

### 2. Activar GitHub Pages
Ve a **Settings → Pages → Source** y selecciona la rama `main`, carpeta `/docs`.

### 3. Activar GitHub Actions
Ve a **Actions → Enable Actions** si no está habilitado.

### 4. Primera ejecución manual
Ve a **Actions → Reporte diario de propiedades → Run workflow** para generar el primer reporte sin esperar al día siguiente.

### 5. Acceder al sitio
Tu reporte estará en: `https://<tu-usuario>.github.io/<nombre-repositorio>/`

El evaluador interactivo estará en: `https://<tu-usuario>.github.io/<nombre-repositorio>/evaluador.html`

## Estructura del repositorio

```
casa-cdmx/
├── .github/
│   └── workflows/
│       └── daily-report.yml     # Workflow de GitHub Actions
├── scripts/
│   └── generar_reporte.py       # Generador del reporte diario
├── docs/
│   ├── _config.yml              # Config de GitHub Pages
│   ├── index.md                 # Reporte del día (se sobreescribe diariamente)
│   ├── evaluador.html           # Evaluador interactivo de propiedades
│   ├── historial.json           # Registro de fechas con reporte
│   └── YYYY-MM-DD.md            # Reportes históricos por fecha
└── README.md
```

## Ajustar parámetros

Todos los parámetros se editan en `scripts/generar_reporte.py`:

- `PRESUPUESTO_MAX` — cambiar tope de renta
- `ZONA["colonias"]` — agregar o quitar colonias
- `PESOS` — ajustar pesos del sistema de evaluación
- `PORTALES` — agregar o quitar portales
